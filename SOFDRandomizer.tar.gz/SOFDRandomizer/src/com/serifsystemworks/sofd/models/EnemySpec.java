package com.serifsystemworks.sofd.models;

public class EnemySpec {
    private int id;
    private String name;
    private int hp;
    private int mp;
    private int attack;
    private int defense;
    private int agility;
    private int expReward;
    private int folReward;
    byte elementResistMask;

    public EnemySpec(int id, String name, int hp, int mp, int attack, int defense, int agility, int expReward, int folReward, byte elementResistMask) {
        this.id = id;
        this.name = name;
        this.hp = hp;
        this.mp = mp;
        this.attack = attack;
        this.defense = defense;
        this.agility = agility;
        this.expReward = expReward;
        this.folReward = folReward;
        this.elementResistMask = elementResistMask;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getHp() { return hp; }
    public void setHp(int hp) { this.hp = hp; }
    public int getMp() { return mp; }
    public void setMp(int mp) { this.mp = mp; }
    public int getAttack() { return attack; }
    public void setAttack(int attack) { this.attack = attack; }
    public int getDefense() { return defense; }
    public void setDefense(int defense) { this.defense = defense; }
    public int getAgility() { return agility; }
    public void setAgility(int agility) { this.agility = agility; }
    public int getExpReward() { return expReward; }
    public void setExpReward(int expReward) { this.expReward = expReward; }
    public int getFolReward() { return folReward; }
    public void setFolReward(int folReward) { this.folReward = folReward; }
    public byte getElementResistMask() { return elementResistMask; }
    public void setElementResistMask(byte elementResistMask) { this.elementResistMask = elementResistMask; }
}