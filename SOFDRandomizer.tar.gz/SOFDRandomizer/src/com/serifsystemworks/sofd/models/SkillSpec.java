package com.serifsystemworks.sofd.models;

public class SkillSpec {

    private int id;
    private String categoryName;
    private String name;
    private int reqSp;
    private int maxLevel;
    private int icSuccessRate;

    public SkillSpec(int id, String categoryName, String name, int reqSp, int maxLevel, int icSuccessRate) {
        this.id = id;
        this.categoryName = categoryName != null ? categoryName : "";
        this.name = name != null ? name : "Skill";
        setReqSp(reqSp);
        this.maxLevel = Math.max(1, maxLevel);
        setIcSuccessRate(icSuccessRate);
    }

    public int getId() { return id; }
    public String getCategoryName() { return categoryName; }
    public String getName() { return name; }
    public int getMaxLevel() { return maxLevel; }

    public int getReqSp() { return reqSp; }
    public void setReqSp(int reqSp) { this.reqSp = Math.min(999, Math.max(1, reqSp)); }

    public int getIcSuccessRate() { return icSuccessRate; }
    public void setIcSuccessRate(int icSuccessRate) { this.icSuccessRate = Math.min(100, Math.max(0, icSuccessRate)); }
}