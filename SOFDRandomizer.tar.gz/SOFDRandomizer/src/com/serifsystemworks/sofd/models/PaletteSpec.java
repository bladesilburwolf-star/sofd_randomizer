package com.serifsystemworks.sofd.models;

public class PaletteSpec {

    private int spriteId;
    private long clutOffset;
    private String paletteName;
    private int colorCount;
    private int[] argbColors;

    public PaletteSpec(int spriteId, long clutOffset, String paletteName, int colorCount) {
        this.spriteId = spriteId;
        this.clutOffset = clutOffset;
        this.paletteName = paletteName != null ? paletteName : "Palette";
        this.colorCount = colorCount;
        this.argbColors = new int[colorCount];
    }

    public int getSpriteId() { return spriteId; }
    public long getClutOffset() { return clutOffset; }
    public String getPaletteName() { return paletteName; }
    public int getColorCount() { return colorCount; }

    public int[] getArgbColors() {
        return argbColors != null ? argbColors.clone() : new int[0];
    }

    public void setArgbColors(int[] argbColors) {
        if (argbColors != null) {
            this.argbColors = argbColors.clone();
        }
    }
}