package com.serifsystemworks.sofd.models;

public class EncounterSpec {

    private int zoneId;
    private String zoneName;
    private int encounterRate;
    private int[] enemySlotIds;
    private boolean bossEncounter;
    private boolean locked;

    public EncounterSpec(int zoneId, String zoneName, int encounterRate, int[] enemySlotIds) {
        this(zoneId, zoneName, encounterRate, enemySlotIds, false, false);
    }

    public EncounterSpec(int zoneId, String zoneName, int encounterRate, int[] enemySlotIds, boolean bossEncounter, boolean locked) {
        this.zoneId = zoneId;
        this.zoneName = zoneName != null ? zoneName : "Map Zone";
        setEncounterRate(encounterRate);
        setEnemySlotIds(enemySlotIds);
        this.bossEncounter = bossEncounter;
        this.locked = locked;
    }

    public int getZoneId() { return zoneId; }
    public String getZoneName() { return zoneName; }

    public int getEncounterRate() { return encounterRate; }
    public void setEncounterRate(int encounterRate) { this.encounterRate = Math.min(100, Math.max(0, encounterRate)); }

    public int[] getEnemySlotIds() {
        return enemySlotIds.clone();
    }

    public void setEnemySlotIds(int[] slots) {
        this.enemySlotIds = new int[6];
        if (slots != null) {
            System.arraycopy(slots, 0, this.enemySlotIds, 0, Math.min(slots.length, 6));
        }
    }

    // Missing methods called by EncounterRandomizer.java
    public boolean isBossEncounter() { return bossEncounter; }
    public void setBossEncounter(boolean bossEncounter) { this.bossEncounter = bossEncounter; }

    public boolean isLocked() { return locked; }
    public void setLocked(boolean locked) { this.locked = locked; }
}