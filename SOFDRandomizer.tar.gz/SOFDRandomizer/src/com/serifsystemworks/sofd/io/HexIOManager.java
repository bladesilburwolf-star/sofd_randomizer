package com.serifsystemworks.sofd.io;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;

public class HexIOManager implements Closeable {

    private final File targetFile;
    private RandomAccessFile raf;
    private FileChannel channel;

    public HexIOManager(File targetFile) {
        if (targetFile == null) {
            throw new IllegalArgumentException("Target file cannot be null.");
        }
        this.targetFile = targetFile;
    }

    /**
     * Opens the persistent file channel for batch read/write operations.
     */
    public void open(boolean readOnly) throws FileNotFoundException {
        if (raf == null) {
            String mode = readOnly ? "r" : "rw";
            this.raf = new RandomAccessFile(targetFile, mode);
            this.channel = raf.getChannel();
        }
    }

    // --- READ OPERATIONS ---

    public int readUInt8(long offset) throws IOException {
        ensureOpen(true);
        ByteBuffer buf = ByteBuffer.allocate(1);
        channel.read(buf, offset);
        buf.flip();
        return buf.get() & 0xFF;
    }

    public short readInt16LE(long offset) throws IOException {
        ensureOpen(true);
        ByteBuffer buf = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN);
        channel.read(buf, offset);
        buf.flip();
        return buf.getShort();
    }

    public int readUInt16LE(long offset) throws IOException {
        return readInt16LE(offset) & 0xFFFF;
    }

    public int readInt32LE(long offset) throws IOException {
        ensureOpen(true);
        ByteBuffer buf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        channel.read(buf, offset);
        buf.flip();
        return buf.getInt();
    }

    public byte[] readBytes(long offset, int length) throws IOException {
        ensureOpen(true);
        ByteBuffer buf = ByteBuffer.allocate(length);
        channel.read(buf, offset);
        return buf.array();
    }

    // --- WRITE OPERATIONS ---

    public void writeUInt8(long offset, int value) throws IOException {
        ensureOpen(false);
        ByteBuffer buf = ByteBuffer.allocate(1);
        buf.put((byte) (value & 0xFF));
        buf.flip();
        channel.write(buf, offset);
    }

    public void writeInt16LE(long offset, int value) throws IOException {
        ensureOpen(false);
        ByteBuffer buf = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN);
        buf.putShort((short) value);
        buf.flip();
        channel.write(buf, offset);
    }

    public void writeInt32LE(long offset, int value) throws IOException {
        ensureOpen(false);
        ByteBuffer buf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(value);
        buf.flip();
        channel.write(buf, offset);
    }

    public void writeBytes(long offset, byte[] data) throws IOException {
        if (data == null || data.length == 0) return;
        ensureOpen(false);
        ByteBuffer buf = ByteBuffer.wrap(data);
        channel.write(buf, offset);
    }

    private void ensureOpen(boolean readOnly) throws IOException {
        if (raf == null || channel == null || !channel.isOpen()) {
            open(readOnly);
        }
    }

    @Override
    public void close() throws IOException {
        if (channel != null && channel.isOpen()) {
            channel.close();
        }
        if (raf != null) {
            raf.close();
            raf = null;
        }
    }

    public File getTargetFile() {
        return targetFile;
    }
}