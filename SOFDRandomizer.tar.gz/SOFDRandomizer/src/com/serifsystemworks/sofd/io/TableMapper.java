package com.serifsystemworks.sofd.io;

import com.serifsystemworks.sofd.models.*;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class TableMapper {

    // Corrected Table Offsets within DATA.BIN Container
    public static final long OFFSET_ENEMIES    = 0x00012000L;
    public static final long OFFSET_DROPS      = 0x00018000L;
    public static final long OFFSET_PARTY      = 0x00020000L;
    public static final long OFFSET_EQUIPMENT  = 0x00024000L;
    public static final long OFFSET_PALETTES   = 0x0002B000L;
    public static final long OFFSET_SKILLS     = 0x00031000L;
    public static final long OFFSET_ENCOUNTERS = 0x00038000L;

    // Table Counts
    public static final int COUNT_ENEMIES    = 64;
    public static final int COUNT_DROPS      = 32;
    public static final int COUNT_PARTY      = 12;
    public static final int COUNT_EQUIPMENT  = 48;
    public static final int COUNT_PALETTES   = 24;
    public static final int COUNT_SKILLS     = 30;
    public static final int COUNT_ENCOUNTERS = 20;

    // Helper: Reads Little-Endian bytes into a sanitized UTF-8 string
    private static String readCleanString(ByteBuffer buf, int length) {
        byte[] raw = new byte[length];
        buf.get(raw);
        int end = 0;
        while (end < raw.length && raw[end] != 0) {
            end++;
        }
        return new String(raw, 0, end, StandardCharsets.UTF_8).trim();
    }

    private static void writeCleanString(ByteBuffer buf, String str, int length) {
        byte[] raw = new byte[length];
        if (str != null) {
            byte[] src = str.getBytes(StandardCharsets.UTF_8);
            System.arraycopy(src, 0, raw, 0, Math.min(src.length, length));
        }
        buf.put(raw);
    }

    // --- ENEMIES ---
    public static List<EnemySpec> loadEnemies(File file) throws Exception {
        List<EnemySpec> list = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel()) {
            
            ByteBuffer buf = ByteBuffer.allocate(COUNT_ENEMIES * 38).order(ByteOrder.LITTLE_ENDIAN);
            channel.read(buf, OFFSET_ENEMIES);
            buf.flip();

            for (int i = 0; i < COUNT_ENEMIES; i++) {
                int id = buf.getShort() & 0xFFFF;
                String name = readCleanString(buf, 16);
                int hp = Math.max(0, Math.min(999_999, buf.getInt()));
                int mp = buf.getShort() & 0xFFFF;
                int atk = buf.getShort() & 0xFFFF;
                int def = buf.getShort() & 0xFFFF;
                int agl = buf.getShort() & 0xFFFF;
                int exp = buf.getInt();
                int fol = buf.getInt();
                byte resist = buf.get();
                buf.get(); // Padding byte

                list.add(new EnemySpec(id, name, hp, mp, atk, def, agl, exp, fol, resist));
            }
        }
        return list;
    }

    public static void saveEnemies(File file, List<EnemySpec> list) throws Exception {
        if (list == null || list.isEmpty()) return;
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(list.size() * 38).order(ByteOrder.LITTLE_ENDIAN);
            for (EnemySpec e : list) {
                buf.putShort((short) (e.getId() & 0xFFFF));
                writeCleanString(buf, e.getName(), 16);
                buf.putInt(Math.max(0, e.getHp()));
                buf.putShort((short) (e.getMp() & 0xFFFF));
                buf.putShort((short) (e.getAttack() & 0xFFFF));
                buf.putShort((short) (e.getDefense() & 0xFFFF));
                buf.putShort((short) (e.getAgility() & 0xFFFF));
                buf.putInt(Math.max(0, e.getExpReward()));
                buf.putInt(Math.max(0, e.getFolReward()));
                buf.put((byte) e.getElementResistMask());
                buf.put((byte) 0); // Padding
            }
            buf.flip();
            channel.write(buf, OFFSET_ENEMIES);
        }
    }

    // --- DROPS ---
    public static List<DropEntry> loadDrops(File file) throws Exception {
        List<DropEntry> list = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(COUNT_DROPS * 10).order(ByteOrder.LITTLE_ENDIAN);
            channel.read(buf, OFFSET_DROPS);
            buf.flip();

            for (int i = 0; i < COUNT_DROPS; i++) {
                int id = buf.getShort() & 0xFFFF;
                int enemyId = buf.getShort() & 0xFFFF;
                int itemId = buf.getShort() & 0xFFFF;
                int rate = Math.min(100, buf.getShort() & 0xFFFF);
                int flags = buf.getShort() & 0xFFFF;

                list.add(new DropEntry(id, enemyId, itemId, rate, flags));
            }
        }
        return list;
    }

    public static void saveDrops(File file, List<DropEntry> list) throws Exception {
        if (list == null || list.isEmpty()) return;
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(list.size() * 10).order(ByteOrder.LITTLE_ENDIAN);
            for (DropEntry d : list) {
                buf.putShort((short) (d.getId() & 0xFFFF));
                buf.putShort((short) (d.getEnemyId() & 0xFFFF));
                buf.putShort((short) (d.getItemId() & 0xFFFF));
                buf.putShort((short) (d.getDropRate() & 0xFFFF));
                buf.putShort((short) (d.getExtraFlags() & 0xFFFF));
            }
            buf.flip();
            channel.write(buf, OFFSET_DROPS);
        }
    }

    // --- PARTY MEMBERS ---
    public static List<PartyMemberSpec> loadParty(File file) throws Exception {
        List<PartyMemberSpec> list = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(COUNT_PARTY * 37).order(ByteOrder.LITTLE_ENDIAN);
            channel.read(buf, OFFSET_PARTY);
            buf.flip();

            for (int i = 0; i < COUNT_PARTY; i++) {
                int id = buf.getShort() & 0xFFFF;
                String name = readCleanString(buf, 16);
                int lvl = buf.get() & 0xFF;
                int hp = Math.max(1, Math.min(9999, buf.getInt()));
                int mp = Math.min(999, buf.getShort() & 0xFFFF);
                int str = Math.min(255, buf.getShort() & 0xFFFF);
                int con = Math.min(255, buf.getShort() & 0xFFFF);
                int agl = Math.min(255, buf.getShort() & 0xFFFF);
                int intel = Math.min(255, buf.getShort() & 0xFFFF);
                int luc = Math.min(255, buf.getShort() & 0xFFFF);
                int weaponId = buf.getShort() & 0xFFFF;

                list.add(new PartyMemberSpec(id, name, lvl, hp, mp, str, con, agl, intel, luc, weaponId));
            }
        }
        return list;
    }

    public static void saveParty(File file, List<PartyMemberSpec> list) throws Exception {
        if (list == null || list.isEmpty()) return;
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(list.size() * 37).order(ByteOrder.LITTLE_ENDIAN);
            for (PartyMemberSpec p : list) {
                buf.putShort((short) (p.getCharacterId() & 0xFFFF));
                writeCleanString(buf, p.getName(), 16);
                buf.put((byte) (p.getLevel() & 0xFF));
                buf.putInt(Math.max(1, p.getHp()));
                buf.putShort((short) (p.getMp() & 0xFFFF));
                buf.putShort((short) (p.getStr() & 0xFFFF));
                buf.putShort((short) (p.getCon() & 0xFFFF));
                buf.putShort((short) (p.getAgl() & 0xFFFF));
                buf.putShort((short) (p.getIntStat() & 0xFFFF));
                buf.putShort((short) (p.getLuc() & 0xFFFF));
                buf.putShort((short) (p.getInitialWeaponId() & 0xFFFF));
            }
            buf.flip();
            channel.write(buf, OFFSET_PARTY);
        }
    }

    // --- EQUIPMENT ---
    public static List<EquipmentSpec> loadEquipment(File file) throws Exception {
        List<EquipmentSpec> list = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(COUNT_EQUIPMENT * 40).order(ByteOrder.LITTLE_ENDIAN);
            channel.read(buf, OFFSET_EQUIPMENT);
            buf.flip();

            for (int i = 0; i < COUNT_EQUIPMENT; i++) {
                int id = buf.getShort() & 0xFFFF;
                String type = readCleanString(buf, 8);
                String name = readCleanString(buf, 16);
                int atk = Math.min(9999, buf.getShort() & 0xFFFF);
                int def = Math.min(9999, buf.getShort() & 0xFFFF);
                int mag = Math.min(9999, buf.getShort() & 0xFFFF);
                int hit = Math.min(9999, buf.getShort() & 0xFFFF);
                int avd = Math.min(9999, buf.getShort() & 0xFFFF);
                int price = Math.max(0, buf.getInt());
                byte elem = buf.get();
                buf.get(); // Padding byte

                list.add(new EquipmentSpec(id, type, name, atk, def, mag, hit, avd, price, elem));
            }
        }
        return list;
    }

    public static void saveEquipment(File file, List<EquipmentSpec> list) throws Exception {
        if (list == null || list.isEmpty()) return;
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(list.size() * 40).order(ByteOrder.LITTLE_ENDIAN);
            for (EquipmentSpec eq : list) {
                buf.putShort((short) (eq.getId() & 0xFFFF));
                writeCleanString(buf, eq.getTypeName(), 8);
                writeCleanString(buf, eq.getName(), 16);
                buf.putShort((short) (eq.getAtk() & 0xFFFF));
                buf.putShort((short) (eq.getDef() & 0xFFFF));
                buf.putShort((short) (eq.getMagAtk() & 0xFFFF));
                buf.putShort((short) (eq.getHit() & 0xFFFF));
                buf.putShort((short) (eq.getAvd() & 0xFFFF));
                buf.putInt(Math.max(0, eq.getPrice()));
                buf.put((byte) eq.getElementMask());
                buf.put((byte) 0); // Padding
            }
            buf.flip();
            channel.write(buf, OFFSET_EQUIPMENT);
        }
    }

    // --- PALETTES ---
    public static List<PaletteSpec> loadPalettes(File file) throws Exception {
        List<PaletteSpec> list = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(COUNT_PALETTES * 24).order(ByteOrder.LITTLE_ENDIAN);
            channel.read(buf, OFFSET_PALETTES);
            buf.flip();

            for (int i = 0; i < COUNT_PALETTES; i++) {
                int spriteId = buf.getShort() & 0xFFFF;
                long clutOffset = buf.getInt() & 0xFFFFFFFFL;
                String name = readCleanString(buf, 16);
                int colors = buf.getShort() & 0xFFFF;

                list.add(new PaletteSpec(spriteId, clutOffset, name, colors));
            }
        }
        return list;
    }

    public static void savePalettes(File file, List<PaletteSpec> list) throws Exception {
        if (list == null || list.isEmpty()) return;
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(list.size() * 24).order(ByteOrder.LITTLE_ENDIAN);
            for (PaletteSpec pal : list) {
                buf.putShort((short) (pal.getSpriteId() & 0xFFFF));
                buf.putInt((int) (pal.getClutOffset() & 0xFFFFFFFFL));
                writeCleanString(buf, pal.getPaletteName(), 16);
                buf.putShort((short) (pal.getColorCount() & 0xFFFF));
            }
            buf.flip();
            channel.write(buf, OFFSET_PALETTES);
        }
    }

    // --- SKILLS ---
    public static List<SkillSpec> loadSkills(File file) throws Exception {
        List<SkillSpec> list = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(COUNT_SKILLS * 32).order(ByteOrder.LITTLE_ENDIAN);
            channel.read(buf, OFFSET_SKILLS);
            buf.flip();

            for (int i = 0; i < COUNT_SKILLS; i++) {
                int id = buf.getShort() & 0xFFFF;
                String cat = readCleanString(buf, 12);
                String name = readCleanString(buf, 16);
                int sp = buf.getShort() & 0xFFFF;
                int maxLvl = buf.get() & 0xFF;
                int icRate = buf.get() & 0xFF;

                list.add(new SkillSpec(id, cat, name, sp, maxLvl, icRate));
            }
        }
        return list;
    }

    public static void saveSkills(File file, List<SkillSpec> list) throws Exception {
        if (list == null || list.isEmpty()) return;
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(list.size() * 32).order(ByteOrder.LITTLE_ENDIAN);
            for (SkillSpec s : list) {
                buf.putShort((short) (s.getId() & 0xFFFF));
                writeCleanString(buf, s.getCategoryName(), 12);
                writeCleanString(buf, s.getName(), 16);
                buf.putShort((short) (s.getReqSp() & 0xFFFF));
                buf.put((byte) (s.getMaxLevel() & 0xFF));
                buf.put((byte) (s.getIcSuccessRate() & 0xFF));
            }
            buf.flip();
            channel.write(buf, OFFSET_SKILLS);
        }
    }

    // --- ENCOUNTERS ---
    public static List<EncounterSpec> loadEncounters(File file) throws Exception {
        List<EncounterSpec> list = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(COUNT_ENCOUNTERS * 32).order(ByteOrder.LITTLE_ENDIAN);
            channel.read(buf, OFFSET_ENCOUNTERS);
            buf.flip();

            for (int i = 0; i < COUNT_ENCOUNTERS; i++) {
                int zoneId = buf.getShort() & 0xFFFF;
                String area = readCleanString(buf, 16);
                int rate = buf.get() & 0xFF;
                buf.get(); // Padding byte
                int[] slots = new int[6];
                for (int s = 0; s < 6; s++) {
                    slots[s] = buf.getShort() & 0xFFFF;
                }

                list.add(new EncounterSpec(zoneId, area, rate, slots));
            }
        }
        return list;
    }

    public static void saveEncounters(File file, List<EncounterSpec> list) throws Exception {
        if (list == null || list.isEmpty()) return;
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw");
             FileChannel channel = raf.getChannel()) {

            ByteBuffer buf = ByteBuffer.allocate(list.size() * 32).order(ByteOrder.LITTLE_ENDIAN);
            for (EncounterSpec enc : list) {
                buf.putShort((short) (enc.getZoneId() & 0xFFFF));
                writeCleanString(buf, enc.getZoneName(), 16);
                buf.put((byte) (enc.getEncounterRate() & 0xFF));
                buf.put((byte) 0); // Padding
                int[] slots = enc.getEnemySlotIds();
                for (int s = 0; s < 6; s++) {
                    buf.putShort((short) ((s < slots.length ? slots[s] : 0) & 0xFFFF));
                }
            }
            buf.flip();
            channel.write(buf, OFFSET_ENCOUNTERS);
        }
    }
}