package com.serifsystemworks.sofd.randomizer;

import java.awt.Color;
import java.util.Random;

public class PaletteRandomizer {

    /**
     * Randomizes raw BGR555 palette byte buffers (16-bit PSP/PS1 format).
     * 
     * @param paletteData Raw byte array containing BGR555 entries
     * @param seed Random seed
     * @param hueShiftOnly If true, applies smooth HSB hue rotation. If false, applies random channel jitter.
     * @param colorsPerBlock Number of colors per palette block (typically 16 or 256) to handle transparency offset correctly
     */
    public static void randomizePaletteBuffer(byte[] paletteData, long seed, boolean hueShiftOnly, int colorsPerBlock) {
        if (paletteData == null || paletteData.length < 2) {
            return;
        }

        Random rng = new Random(seed);
        float hueOffset = rng.nextFloat(); // Dynamic seed-based hue offset

        int totalEntries = paletteData.length / 2;

        for (int entryIndex = 0; entryIndex < totalEntries; entryIndex++) {
            // Preserve Index 0 of each palette block (transparency key)
            if (colorsPerBlock > 0 && (entryIndex % colorsPerBlock) == 0) {
                continue;
            }

            int byteOffset = entryIndex * 2;

            // Read Little-Endian 16-bit word
            int colorWord = ((paletteData[byteOffset + 1] & 0xFF) << 8) | (paletteData[byteOffset] & 0xFF);

            // Extract 5-bit BGR components and 1-bit alpha/transparency flag (bit 15)
            int r = colorWord & 0x1F;
            int g = (colorWord >> 5) & 0x1F;
            int b = (colorWord >> 10) & 0x1F;
            int stp = colorWord & 0x8000; // Semi-transparency flag

            int newR, newG, newB;

            if (hueShiftOnly) {
                // Scale 5-bit (0-31) up to 8-bit (0-255) for standard HSB math
                float[] hsb = Color.RGBtoHSB(r << 3, g << 3, b << 3, null);
                float newHue = (hsb[0] + hueOffset) % 1.0f;
                int rgb = Color.HSBtoRGB(newHue, hsb[1], hsb[2]);

                // Convert back down to 5-bit
                newR = ((rgb >> 16) & 0xFF) >> 3;
                newG = ((rgb >> 8) & 0xFF) >> 3;
                newB = (rgb & 0xFF) >> 3;
            } else {
                // Seed-based random variance (-4 to +4 steps in 5-bit color space)
                newR = Math.min(31, Math.max(0, r + (rng.nextInt(9) - 4)));
                newG = Math.min(31, Math.max(0, g + (rng.nextInt(9) - 4)));
                newB = Math.min(31, Math.max(0, b + (rng.nextInt(9) - 4)));
            }

            // Reconstruct BGR555 word with strict 5-bit masking to prevent bit leaking
            int newColorWord = stp | ((newB & 0x1F) << 10) | ((newG & 0x1F) << 5) | (newR & 0x1F);

            // Write back in Little-Endian format
            paletteData[byteOffset] = (byte) (newColorWord & 0xFF);
            paletteData[byteOffset + 1] = (byte) ((newColorWord >> 8) & 0xFF);
        }
    }

    /**
     * Overloaded helper method assuming a single contiguous palette block.
     */
    public static void randomizePaletteBuffer(byte[] paletteData, long seed, boolean hueShiftOnly) {
        randomizePaletteBuffer(paletteData, seed, hueShiftOnly, 0);
    }
}