package com.serifsystemworks.sofd.randomizer;

import com.serifsystemworks.sofd.models.EnemySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public class SeedManager {

    public enum Preset {
        BALANCED("Standard Run", 0.8f, 1.2f),
        CHAOS("Chaos Mode", 0.4f, 2.5f),
        HARDCORE("Hardcore Scaling", 1.2f, 3.0f);

        private final String label;
        private final float minScale;
        private final float maxScale;

        Preset(String label, float minScale, float maxScale) {
            this.label = label;
            this.minScale = minScale;
            this.maxScale = maxScale;
        }

        public String getLabel() { return label; }
        public float getMinScale() { return minScale; }
        public float getMaxScale() { return maxScale; }
    }

    /**
     * Converts a text seed into a robust 64-bit seed using SHA-256.
     */
    public static long parseSeed(String seedText) {
        if (seedText == null || seedText.trim().isEmpty()) {
            return System.currentTimeMillis();
        }

        String sanitized = seedText.trim();

        // Check if string is already a numeric long value
        try {
            return Long.parseLong(sanitized);
        } catch (NumberFormatException ignored) {
            // Fall back to SHA-256 hashing for strong 64-bit entropy
        }

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(sanitized.getBytes(StandardCharsets.UTF_8));
            
            // Extract long from first 8 bytes
            long seed = 0;
            for (int i = 0; i < 8; i++) {
                seed = (seed << 8) | (hash[i] & 0xFF);
            }
            return seed;
        } catch (NoSuchAlgorithmException e) {
            // Safe fallback if SHA-256 is unavailable
            return sanitized.hashCode();
        }
    }

    /**
     * Applies a seed and preset configuration by delegating directly to EnemyRandomizer.
     */
    public static void applySeedAndPreset(List<EnemySpec> enemies, String seedText, Preset preset) {
        if (enemies == null || enemies.isEmpty()) {
            return;
        }

        Preset targetPreset = (preset != null) ? preset : Preset.BALANCED;
        long seed = parseSeed(seedText);

        // Delegate execution to EnemyRandomizer to eliminate duplicated code
        EnemyRandomizer randomizer = new EnemyRandomizer(seed);
        randomizer.setScaleMin(targetPreset.getMinScale());
        randomizer.setScaleMax(targetPreset.getMaxScale());
        randomizer.processEnemies(enemies);
    }
}