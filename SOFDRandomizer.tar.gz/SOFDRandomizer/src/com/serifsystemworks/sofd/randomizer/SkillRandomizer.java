package com.serifsystemworks.sofd.randomizer;

import com.serifsystemworks.sofd.models.SkillSpec;
import java.util.List;
import java.util.Random;

public class SkillRandomizer {

    private static final int MAX_SP_COST = 999;
    private static final int MAX_SUCCESS_RATE = 100;

    /**
     * Randomizes SP costs and optional Item Creation (IC) success rates for skills.
     * 
     * @param skills List of skill specifications to randomize
     * @param scale Base scaling factor for SP costs
     * @param spMultiplier Secondary multiplier dedicated to SP cost tuning
     * @param boostIcSuccess If true, boosts specialty/IC skill success rates
     * @param rng Random instance
     */
    public static void randomize(List<SkillSpec> skills, double scale, double spMultiplier, boolean boostIcSuccess, Random rng) {
        if (skills == null || skills.isEmpty()) {
            return;
        }

        double totalSpMultiplier = Math.max(0.1, scale * spMultiplier);

        for (SkillSpec skill : skills) {
            if (skill == null) {
                continue;
            }

            // Calculate and cap new required SP
            int currentSp = skill.getReqSp();
            if (currentSp > 0) {
                int newSp = (int) Math.round(currentSp * totalSpMultiplier);
                skill.setReqSp(Math.min(MAX_SP_COST, Math.max(1, newSp)));
            }

            // Apply Item Creation (IC) / Specialty success rate adjustments
            if (boostIcSuccess && "Specialty".equalsIgnoreCase(skill.getCategoryName())) {
                int currentRate = skill.getIcSuccessRate();
                
                // Only boost skills that actually have a base success rate
                if (currentRate > 0 && rng != null) {
                    int boost = 20 + rng.nextInt(15); // +20% to +34% boost
                    int boostedRate = Math.min(MAX_SUCCESS_RATE, currentRate + boost);
                    skill.setIcSuccessRate(boostedRate);
                }
            }
        }
    }
}