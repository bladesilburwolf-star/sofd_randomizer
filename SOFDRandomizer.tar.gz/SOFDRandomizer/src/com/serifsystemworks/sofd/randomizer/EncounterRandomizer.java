package com.serifsystemworks.sofd.randomizer;

import com.serifsystemworks.sofd.models.EncounterSpec;
import java.util.List;
import java.util.Random;

public class EncounterRandomizer {

    /**
     * Randomizes enemy slots across all provided encounter zones.
     * 
     * @param encounters List of encounter specifications to randomize
     * @param maxEnemyId Maximum valid enemy ID (1 to maxEnemyId)
     * @param rng Random instance to maintain seed continuity
     */
    public static void randomize(List<EncounterSpec> encounters, int maxEnemyId, Random rng) {
        randomize(encounters, maxEnemyId, rng, false);
    }

    /**
     * Overloaded randomize method with option to include empty (0) slots.
     * 
     * @param encounters List of encounter specifications
     * @param maxEnemyId Maximum valid enemy ID
     * @param rng Random instance
     * @param includeEmptySlots If true, slots set to 0 will also be assigned enemies
     */
    public static void randomize(List<EncounterSpec> encounters, int maxEnemyId, Random rng, boolean includeEmptySlots) {
        if (encounters == null || encounters.isEmpty() || maxEnemyId <= 0 || rng == null) {
            return;
        }

        for (EncounterSpec zone : encounters) {
            if (zone == null) {
                continue;
            }

            // Skip boss or locked event encounters if flag is present
            if (zone.isBossEncounter() || zone.isLocked()) {
                continue;
            }

            int[] slots = zone.getEnemySlotIds();
            if (slots == null || slots.length == 0) {
                continue;
            }

            boolean modified = false;
            for (int i = 0; i < slots.length; i++) {
                // Randomize slot if populated or if explicitly requested to fill empty slots
                if (slots[i] != 0 || includeEmptySlots) {
                    slots[i] = 1 + rng.nextInt(maxEnemyId);
                    modified = true;
                }
            }

            // Persist back if modified
            if (modified) {
                zone.setEnemySlotIds(slots);
            }
        }
    }
}