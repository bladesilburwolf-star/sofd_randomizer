package com.serifsystemworks.sofd.randomizer;

import com.serifsystemworks.sofd.models.DropEntry;
import java.util.List;
import java.util.Random;

public class DropTableEngine {

    private final Random rng;
    private long seed;
    private int maxItemId;

    public DropTableEngine() {
        this(System.currentTimeMillis());
    }

    public DropTableEngine(long seed) {
        this.seed = seed;
        this.rng = new Random(seed);
        this.maxItemId = 512; // Adjust based on total valid SOFD item IDs
    }

    public long getSeed() {
        return seed;
    }

    public void setSeed(long seed) {
        this.seed = seed;
        this.rng.setSeed(seed);
    }

    public int getMaxItemId() {
        return maxItemId;
    }

    public void setMaxItemId(int maxItemId) {
        this.maxItemId = maxItemId;
    }

    /**
     * Randomizes a list of drops using the instance RNG state.
     */
    public void randomize(List<DropEntry> drops) {
        randomizeDrops(drops, this.maxItemId, this.rng, false);
    }

    /**
     * Randomizes a list of drops using the instance RNG state, optionally allowing empty slots (0) to be filled.
     */
    public void randomize(List<DropEntry> drops, boolean randomizeEmptySlots) {
        randomizeDrops(drops, this.maxItemId, this.rng, randomizeEmptySlots);
    }

    /**
     * Static helper method to process drop tables.
     * 
     * @param drops List of drop entries to mutate
     * @param maxItemId Highest valid item ID index
     * @param rng Random instance to use
     * @param randomizeEmptySlots If true, items with ID 0 (empty) will also receive randomized drops
     */
    public static void randomizeDrops(List<DropEntry> drops, int maxItemId, Random rng, boolean randomizeEmptySlots) {
        if (drops == null || drops.isEmpty() || maxItemId <= 0 || rng == null) {
            return;
        }

        for (DropEntry drop : drops) {
            if (drop == null) continue;

            // Only randomize if item is valid or if explicitly targeting empty slots
            if (drop.getItemId() > 0 || randomizeEmptySlots) {
                // Assign new random item ID (1 to maxItemId inclusive)
                drop.setItemId(1 + rng.nextInt(maxItemId));

                // Apply +-10% variance to existing drop rate, clamped between 1% and 100%
                int currentRate = drop.getDropRate() <= 0 ? 5 : drop.getDropRate(); // Fallback for 0% base rates
                int delta = rng.nextInt(21) - 10; // Value between -10 and +10
                int newRate = Math.min(100, Math.max(1, currentRate + delta));
                
                drop.setDropRate(newRate);
            }
        }
    }

    public static void randomizeDrops(List<DropEntry> drops, int maxItemId, Random rng) {
        randomizeDrops(drops, maxItemId, rng, false);
    }
}