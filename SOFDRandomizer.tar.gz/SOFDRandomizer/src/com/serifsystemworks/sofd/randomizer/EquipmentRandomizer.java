package com.serifsystemworks.sofd.randomizer;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Random;

public class EquipmentRandomizer {
    private static final int ENTRY_SIZE = 0x40; // 64 bytes per entry
    
    // Field Relative Offsets
    private static final int OFFSET_ATK = 0x08;
    private static final int OFFSET_DEF = 0x0A;
    private static final int OFFSET_PRICE = 0x18;
    private static final int OFFSET_SELL = 0x1C;

    public static void randomizeEquipment(byte[] fileBuffer, int tableBaseOffset, int itemCount, double variance, long seed) {
        Random rng = new Random(seed);
        ByteBuffer buffer = ByteBuffer.wrap(fileBuffer);
        buffer.order(ByteOrder.LITTLE_ENDIAN); // PSP target uses Little-Endian

        for (int i = 0; i < itemCount; i++) {
            int entryStart = tableBaseOffset + (i * ENTRY_SIZE);

            // 1. Randomize ATK
            short currentAtk = buffer.getShort(entryStart + OFFSET_ATK);
            if (currentAtk > 0) {
                short newAtk = calculateVariance(currentAtk, variance, rng);
                buffer.putShort(entryStart + OFFSET_ATK, newAtk);
            }

            // 2. Randomize DEF
            short currentDef = buffer.getShort(entryStart + OFFSET_DEF);
            if (currentDef > 0) {
                short newDef = calculateVariance(currentDef, variance, rng);
                buffer.putShort(entryStart + OFFSET_DEF, newDef);
            }

            // 3. Scale Prices
            int currentPrice = buffer.getInt(entryStart + OFFSET_PRICE);
            if (currentPrice > 0) {
                int newPrice = Math.max(1, calculateVariance(currentPrice, variance, rng));
                buffer.putInt(entryStart + OFFSET_PRICE, newPrice);
                buffer.putInt(entryStart + OFFSET_SELL, newPrice / 2);
            }
        }
    }

    private static short calculateVariance(short baseValue, double variance, Random rng) {
        double factor = (1.0 - variance) + (rng.nextDouble() * (variance * 2.0));
        int result = (int) Math.round(baseValue * factor);
        return (short) Math.min(Math.max(result, 1), Short.MAX_VALUE);
    }

    private static int calculateVariance(int baseValue, double variance, Random rng) {
        double factor = (1.0 - variance) + (rng.nextDouble() * (variance * 2.0));
        return (int) Math.round(baseValue * factor);
    }
}