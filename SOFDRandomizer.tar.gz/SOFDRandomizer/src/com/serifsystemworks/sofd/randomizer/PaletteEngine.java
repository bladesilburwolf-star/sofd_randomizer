package com.serifsystemworks.sofd.randomizer;

import com.serifsystemworks.sofd.models.PaletteSpec;
import java.awt.Color;
import java.util.List;
import java.util.Random;

public class PaletteEngine {

    public enum Mode {
        HUE_SHIFT,
        COLOR_SWAP,
        PURE_RANDOM
    }

    /**
     * Default palette randomization using Hue Shifting to preserve sprite shading.
     */
    public static void randomizePalettes(List<PaletteSpec> palettes, Random rng) {
        randomizePalettes(palettes, rng, Mode.HUE_SHIFT, false);
    }

    /**
     * Advanced palette randomization with mode selection.
     * 
     * @param palettes List of palette definitions
     * @param rng Random instance
     * @param mode Randomization style (HUE_SHIFT recommended)
     * @param preserveTransparentColor If true, index 0 is skipped to maintain UI/sprite transparency
     */
    public static void randomizePalettes(List<PaletteSpec> palettes, Random rng, Mode mode, boolean preserveTransparentColor) {
        if (palettes == null || palettes.isEmpty() || rng == null) {
            return;
        }

        for (PaletteSpec spec : palettes) {
            if (spec == null) {
                continue;
            }

            int[] colors = spec.getArgbColors();
            if (colors == null || colors.length == 0) {
                continue;
            }

            // Generate a global hue offset per palette to keep color harmony
            float hueOffset = rng.nextFloat(); 

            int startIndex = preserveTransparentColor ? 1 : 0;

            for (int i = startIndex; i < colors.length; i++) {
                int originalColor = colors[i];
                int a = (originalColor >> 24) & 0xFF;

                // Skip fully transparent pixels
                if (a == 0 && preserveTransparentColor) {
                    continue;
                }

                int r = (originalColor >> 16) & 0xFF;
                int g = (originalColor >> 8) & 0xFF;
                int b = originalColor & 0xFF;

                int newColor;

                switch (mode) {
                    case HUE_SHIFT:
                        newColor = shiftHue(r, g, b, a, hueOffset);
                        break;

                    case COLOR_SWAP:
                        // Randomly shuffle channels per palette entry while preserving luminance
                        newColor = (a << 24) | (g << 16) | (b << 8) | r;
                        break;

                    case PURE_RANDOM:
                    default:
                        int newR = rng.nextInt(256);
                        int newG = rng.nextInt(256);
                        int newB = rng.nextInt(256);
                        newColor = (a << 24) | (newR << 16) | (newG << 8) | newB;
                        break;
                }

                colors[i] = newColor;
            }

            spec.setArgbColors(colors);
        }
    }

    /**
     * Converts RGB to HSB, applies hue shift, and converts back to ARGB.
     */
    private static int shiftHue(int r, int g, int b, int a, float hueOffset) {
        float[] hsb = Color.RGBtoHSB(r, g, b, null);
        float newHue = (hsb[0] + hueOffset) % 1.0f;
        int rgb = Color.HSBtoRGB(newHue, hsb[1], hsb[2]);
        
        // Restore original alpha channel
        return (a << 24) | (rgb & 0x00FFFFFF);
    }
}