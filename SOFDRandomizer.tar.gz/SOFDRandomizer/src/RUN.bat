@echo off
cd /d "%~dp0"
echo Compiling...
javac -encoding UTF-8 com/serifsystemworks/sofd/models/*.java com/serifsystemworks/sofd/io/*.java com/serifsystemworks/sofd/randomizer/*.java com/serifsystemworks/sofd/ui/*.java
if errorlevel 1 (
    echo Compile failed.
    pause
    exit /b 1
)
echo Starting editor...
java com.serifsystemworks.sofd.ui.MainFrame
pause
