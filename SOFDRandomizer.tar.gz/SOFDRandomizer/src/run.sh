#!/bin/bash
cd "$(dirname "$0")"
echo "Compiling..."
javac -encoding UTF-8 \
  com/serifsystemworks/psp2/models/*.java \
  com/serifsystemworks/psp2/io/*.java \
  com/serifsystemworks/psp2/randomizer/*.java \
  com/serifsystemworks/psp2/ui/*.java
if [ $? -ne 0 ]; then
  echo "Compile failed."
  exit 1
fi
echo "Starting editor..."
java com.serifsystemworks.psp2.ui.MainFrame
